class Agent:

    def solve(problem):

        # print("Solving %s using visual methods with %d possible answers" % (problem.name, possible_answers))

        return -1